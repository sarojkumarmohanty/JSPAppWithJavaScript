-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: studentadmission
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student_info`
--

DROP TABLE IF EXISTS `student_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_info` (
  `roll_no` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone_no` varchar(45) NOT NULL,
  `college_name` varchar(45) NOT NULL,
  `branch` int NOT NULL,
  `cgpa` double NOT NULL,
  `dob` date NOT NULL,
  `student_type` varchar(45) NOT NULL,
  `interest_area` varchar(45) NOT NULL,
  `address_id` int NOT NULL,
  `is_deleted` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`roll_no`),
  KEY `student_info_branch_fk_idx` (`branch`),
  KEY `student_info_address_fk_idx` (`address_id`),
  CONSTRAINT `student_info_address_fk` FOREIGN KEY (`address_id`) REFERENCES `tbl_address` (`address_id`),
  CONSTRAINT `student_info_branch_fk` FOREIGN KEY (`branch`) REFERENCES `branch_info` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_info`
--

LOCK TABLES `student_info` WRITE;
/*!40000 ALTER TABLE `student_info` DISABLE KEYS */;
INSERT INTO `student_info` VALUES (1,'Amit Sahoo','amit@gmail.com','9876664534','GITA Engg. College',10,8.3,'2000-11-03','regular','art, literature',1,'NO'),(2,'Anil Das','anil@gmail.com','9876667656','DRIEMS',30,5.3,'2000-11-09','lateralentry','science',2,'NO'),(3,'Ali Ahmad','ali@gmail.com','9876664534','GEC',30,5.3,'1998-11-02','regular','science',3,'NO'),(4,'Aman Barma','aman@gmail.com','8978886756','Trident Engg. College',30,7.3,'1999-11-09','regular','art, literature',4,'NO'),(5,'Sunil Sahoo','sunil@gmail.com','9876667656','GEC',40,7.3,'2000-03-07','regular','art, literature',5,'NO'),(6,'Sumit Nanda','sumit@gmail.com','9876664534','DRIEMS',20,8.3,'1999-02-09','regular','literature',6,'NO'),(7,'Sumitra Das','sumitra@gmail.com','9876765434','GEC',10,8.3,'2001-01-29','regular','science, literature',7,'NO'),(8,'Sukant Sahoo','sukant@rediffmail.com','9876667656','Trident Engg. College',10,7.3,'2001-02-06','regular','art, literature',9,'NO'),(9,'Harshikesh Singh','h@gmail.com','9876665654','GITA Engg. College',10,9.6,'2000-03-08','regular','art, science',10,'NO'),(10,'Little','little@gmail.com','9876765654','REC',10,8.3,'1999-02-09','regular','art, science, literature',11,'NO'),(11,'Prashant Das','prashant@gmail.com','9876664534','GITA Engg. College',20,8.3,'2000-03-07','regular','art, literature',12,'NO');
/*!40000 ALTER TABLE `student_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-08 17:52:51
